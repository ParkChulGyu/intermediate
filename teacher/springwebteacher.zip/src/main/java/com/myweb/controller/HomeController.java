package com.myweb.controller;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.myweb.dto.MemberDTO;

@Controller
public class HomeController {
	
	

	
	   @RequestMapping(value = "/", method = {RequestMethod.GET, RequestMethod.POST})
	   public String index() {   
	      
	      return "index";
	   }
	
	
	
	@RequestMapping(value = "request", method = RequestMethod.GET)
	public String request() {
		System.out.println("request");
		
		return "test/request";	                  //앞에 test는 폴더 명  뒤에 request는 파일 명
		
	}
	
	@RequestMapping(value = "get", method = RequestMethod.GET)
	public String get(@RequestParam String id) {
		System.out.println("getRequst");
		System.out.println("id : " + id);
		
		
		return "test/request";		
	}
	
	@GetMapping("get2")      //get방식으로 받을 때 주로 사용
	public String get2(@RequestParam("id2") String id) {
		System.out.println("getRequst2");
		System.out.println("id : " + id);
		
		
		return "test/request";		
	}
	
	@RequestMapping(value = "postDTO", method = RequestMethod.POST)
	public String post(MemberDTO dto) {
		System.out.println("postDTO");
		System.out.println("id : " + dto.getId());
		System.out.println("pw : " + dto.getPw());
		
		ModelAndView mav = new ModelAndView();		
		mav.setViewName("index");
		
		return "test/request";	
		
	}
	
	@PostMapping("postMap")
	public String postMap(@RequestParam Map<String, String> map) {
		System.out.println("postMap");
		System.out.println("map확인 : "+ map);
		System.out.println("id : " + map.get("id"));
		System.out.println("pw : " + map.get("pw"));
		
		ModelAndView mav = new ModelAndView();		
		mav.setViewName("index");
		
		return "test/request";	
		
	}
	
	@PostMapping("postList")
	public String postList(@RequestParam("id") List<String> ids) {
		System.out.println("postList");
		System.out.println("ids : " + ids);
		System.out.println("id : " + ids.get(0));
		//System.out.println("pw : " + ids.get(1));
		
		ModelAndView mav = new ModelAndView();		
		mav.setViewName("index");
		
		return "test/request";	
		
	}
	
	@PostMapping(value = "postSM")
	public String postSM(MemberDTO dto, Model model) {
		System.out.println("postSM");
		System.out.println("id : " + dto.getId());
		System.out.println("pw : " + dto.getPw());
		
		model.addAttribute("dto",dto);
		
			
		return "test/response";	
		
	}
	
	@PostMapping(value = "postMAV")
	public ModelAndView postMAV(MemberDTO dto) {
		System.out.println("postMAV");
		System.out.println("id : " + dto.getId());
		System.out.println("pw : " + dto.getPw());
		
		ModelAndView mav = new ModelAndView();		
		
		mav.addObject("dto",dto);
		mav.setViewName("test/response");
		
		return mav;
		
	}

	
	
}
